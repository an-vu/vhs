# Code cleanup review

Reviewed the site's HTML, JavaScript module references, CSS references, and Python launcher after moving the lab. These are cleanup candidates; experiments and production behavior have been retained.

## Unused code and files

- `styles/site.css`: `.home-link` and `.home-link:hover` have no matching class in the current HTML or JavaScript. These rules can be removed.
- `styles/model-test.css`: `.effect-category` has no matching class in the current HTML or JavaScript. This rule can be removed.
- `.DS_Store` files are macOS metadata, not site assets. They can be removed and excluded from future source control or deployment.
- No JavaScript or CSS file was found to be unreferenced by the current pages and modules. The tiny `scripts/pages/legal.js` and `scripts/tests/model-preview-presets.js` files are still used.
- An unlinked lab page is not necessarily unused: these pages are accessed directly during development. Similarly, `404.html` is a hosting error page and should be retained.

## Redundant experiments

- `dev/lab/f35-test.html` and `dev/lab/rb18-test.html` repeat nearly identical inline styles, import maps, and scene setup. The unified `dev/lab/model-test.html` already previews both models. If the standalone demos are no longer needed, remove those two pages and `scripts/tests/f35-test.js` / `scripts/tests/rb18-test.js` together. Otherwise, share their demo CSS and initialization.
- `dev/lab/curiosity-test.html` only redirects to `model-test.html`. Retain it if anyone uses the old lab filename; otherwise it can be removed. It no longer preserves the previous `/prototype/curiosity-test.html` URL after the requested folder move.
- `dev/lab/vhs-prototype.html` is an 881-line standalone prototype with its own inline styles and script. It is not referenced by the production site. Archive or remove it if it is no longer a useful design reference.

## Repetition and maintenance

- Three.js import maps repeat in the homepage, About page, and three model lab pages. Keep their versions synchronized. A shared build/template could centralize this if a build system is added later.
- Production pages repeat favicon, social metadata, header, and footer markup. Shared templates would reduce maintenance, but introducing a build system solely for this small static site may add more complexity than it saves.
- `legal.html` uses `styles/work.css` and the `.work-year` / `.project` structure. Those styles are used, not dead code. Extract common content-list styles if those two page designs start to diverge.
- `scripts/pages/work.js` and `scripts/shared/content-list.js` both close other project details and scroll an opened project into view. A hash-triggered open also triggers the shared toggle handler. Consolidating that behavior would avoid duplicate scrolling while preserving deep links and keyboard behavior.
- `scripts/model/point-material.js` contains many unnecessarily split expressions. Formatting it more compactly would improve readability without changing the shader.
- `scripts/tests/model-test.js` combines asset discovery, loading, rendering, settings UI, animation playback, and cleanup in 573 lines. Splitting loading and UI binding into focused modules would make future changes easier.
- `scripts/model/scene.js`, `scripts/model/background.js`, and `scripts/model/controls.js` keep listeners/observers alive for the page lifetime. That is acceptable for the current full-page site. Add explicit teardown before reusing them in a client-rendered app; the playground and About renderer already have cleanup routines.

## Verification and limits

- All 134 checked local HTML links/assets, JavaScript imports and URL-based asset paths, and CSS asset paths resolve. HTML import maps parse as JSON.
- Exercised the moved launcher's `main()` with a temporary local port: 60 requests covering all root pages, six lab pages, JavaScript, CSS, and the model directory returned HTTP 200 with nonempty bodies. The homepage response matched the root `index.html`.
- Port 6969 was already occupied, so the existing server was left running. The test substituted only the bind address/port; normal invocation remains `python3 dev/serve.py` on port 6969.
- No browser or JavaScript runtime was available for browser interaction, JavaScript syntax checks, or WebGL rendering tests. HTTP/path checks cannot establish that every interactive effect works or identify every unused CSS declaration. External CDN availability was not tested.
